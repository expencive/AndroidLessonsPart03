# Kotlin-Singleton-Example
Example of creating Singletons with Kotlin with some MVVM architecture
